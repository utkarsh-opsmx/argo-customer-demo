package com.opsmx.policyservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeploymentDTO {

    private String eventStatus;
    private String deployTool;
    private String sealId;
    private String jetId;
    private String repoName;
    private String projectName;
    private String branch;
    private String eventSubType;
    private String commitId;
    private String sourceUri;
    private String artifactId;
    private String artifactLocation;
    private String dev;
    private String initiator;
    private String extPayload;

    private String deploymentCompletionTime;
}
