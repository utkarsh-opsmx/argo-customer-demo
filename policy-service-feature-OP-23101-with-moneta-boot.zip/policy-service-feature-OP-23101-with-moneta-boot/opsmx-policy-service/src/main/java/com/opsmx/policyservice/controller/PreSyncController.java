package com.opsmx.policyservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

@RestController
@RequestMapping(value = "/presync")
public class PreSyncController {

    private final RestClient restClient;
    
    @Value("${client.evidenceStore.host}")
    private String evidenceStoreHost;

    @Value("${client.servicenow.host}")
    private String servicenoeHost;

    PreSyncController(final RestClient restClient){
        this.restClient = restClient;
    }

    @GetMapping(value = "/checkReleaseStatus")
    public ResponseEntity<String> validateArtifact(
            @RequestParam("jetId") String jetId,
            @RequestParam("branch") String branch,
            @RequestParam("sealId")  String sealId,
            @RequestParam("artifactCreateDate") Integer artifactCreateDate){
        return restClient
                .get()
                .uri(uriBuilder ->
                        uriBuilder.path(evidenceStoreHost+"/api/v0.0/releaseready/pipeline/jetId")
                                .queryParam("jetId", jetId)
                                .queryParam("branch", branch)
                                .queryParam("sealId", sealId)
                                .queryParam("artifactCreateDate", artifactCreateDate)
                                .build())
                .retrieve()
                .toEntity(String.class);
    }

    @GetMapping(value = "/checkSnowStatus")
    public ResponseEntity<String> checkSnowStatus( @RequestParam("snowId") String snowId){
        return restClient
                .get()
                .uri( uriBuilder ->
                        uriBuilder.path(servicenoeHost+"/api/snow/changes/"+snowId)
                                .build())
                .retrieve()
                .toEntity(String.class);
    }

}
