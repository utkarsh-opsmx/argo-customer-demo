package com.opsmx.policyservice.config;

import com.jpmorgan.moneta.boot.ida.client.IdaTokenRetrievalStrategies;
import com.jpmorgan.moneta.boot.ida.client.auth.UsernameAndPasswordProvider;
import com.jpmorgan.moneta.boot.ida.client.blocking.IdaClientTokenProvider;
import com.jpmorgan.moneta.boot.ida.client.blocking.IdaRestClient;
import com.jpmorgan.moneta.boot.ida.client.blocking.IdaTokenProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

import java.util.Objects;

@Configuration
public class RestClientConfig {
    @Value("${application.ida-provider-url}")
    private String providerUrl;

    @Value("${application.ida-protected-resource-uri}")
    private String protectedResourceUri;

    @Value("${application.ida-client-id}")
    private String clientId;

    @Value("${application.ida-client-keystore-class-path}")
    private String clientKeystoreClassPath;

    @Value("${application.ida-client-keystore-secret}")
    private String clientKeystoreSecret;

    @Bean
    public IdaTokenProvider x509CertificateIdaTokenProvider() {
        return IdaClientTokenProvider.builder().id("x509-certificate-provider").providerUrl(providerUrl)
                .clientId(clientId).resourceUri(protectedResourceUri)
                .tokenRetrievalStrategy(IdaTokenRetrievalStrategies.x509Certificate(
                        Objects.requireNonNull(this.getClass().getResourceAsStream(clientKeystoreClassPath)), clientKeystoreSecret))
                .build();
    }

    @Bean
    public RestClient x509CertificateRestClient(final RestClient.Builder restClientBuilder,
                                                @Qualifier("x509CertificateIdaTokenProvider")  final IdaTokenProvider idaTokenProvider) {
        return IdaRestClient.builder().restClientBuilder(restClientBuilder).tokenProvider(idaTokenProvider)
                .build();
    }
}
