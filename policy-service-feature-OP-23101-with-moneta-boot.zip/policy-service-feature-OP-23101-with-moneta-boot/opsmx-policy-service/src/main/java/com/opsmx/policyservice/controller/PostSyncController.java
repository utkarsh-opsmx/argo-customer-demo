package com.opsmx.policyservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opsmx.policyservice.model.DeploymentDTO;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@RestController
@RequestMapping(value = "/postsync")
public class PostSyncController {

    private final RestClient restClient;

    @Value("${client.evidenceStore.host}")
    private String evidenceStoreHost;

    PostSyncController(final RestClient restClient){
        this.restClient = restClient;
    }
    
    @PostMapping(value = "/submitDeployment")
    public ResponseEntity<String> submitDeployment(@RequestBody DeploymentDTO deployment){
        return restClient
                .post()
                .uri(evidenceStoreHost+"/api/v0.0/deploys/event")
                .contentType(APPLICATION_JSON)
                .body(deployment)
                .retrieve()
                .toEntity(String.class);
    }

}