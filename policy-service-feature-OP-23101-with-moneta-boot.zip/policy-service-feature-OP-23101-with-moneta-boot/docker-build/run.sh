#!/bin/bash

APP_NAME="policy"
APP_FULL_NAME="oes-${APP_NAME}"
APP_JAR="${WORK_DIR}/policy-service-0.0.1-SNAPSHOT.jar"
PORT=8092

JAVA_OPTS+="\
    -Dspring.application.name=${APP_FULL_NAME} \
    -Dspring.config.location=file:///opsmx/conf/ \
    -Dspring.config.name=application,${APP_NAME},feature \
    -Dspring.cloud.bootstrap.name=bootstrap \
    -Dspring.cloud.bootstrap.location=file:///opsmx/conf/ \
    -Dspring.profiles.active=default,vault,local \
    -XX:+UseG1GC \
    -jar"
#    -Dclient-id=REPLACE_ME -Dclient-username=REPLACE_ME -Dclient-secret=REPLACE_ME


#JAVA_NEWRELIC_AGENT=""
#JAVA_NEWRELIC_PROPERTIES=""
#if [ -s "${WORK_DIR}/newrelic/newrelic.jar" ] && [ ! -z "$NEWRELIC_LICENSE" ] && [ ! -z "$NEWRELIC_SVCNAME" ] ; then
#    JAVA_NEWRELIC_AGENT="-javaagent:${WORK_DIR}/newrelic/newrelic.jar"
#    JAVA_NEWRELIC_PROPERTIES="-Dnewrelic.config.license_key=${NEWRELIC_LICENSE} -Dnewrelic.config.app_name=${NEWRELIC_SVCNAME}"
#fi

#APP_FLAGS=""
#if [ ! -z "$VAULT_URI$VAULT_TOKEN"  ] ; then
#    APP_FLAGS="$APP_FLAGS --VAULT_URI=${VAULT_URI} --VAULT_TOKEN=${VAULT_TOKEN}"
#fi

java \
    -Dserver.port=${PORT} $JAVA_OPTS \
    $JAVA_NEWRELIC_AGENT $JAVA_NEWRELIC_PROPERTIES \
    ${APP_JAR} ${APP_FLAGS}

echo "${APP_FULL_NAME} service started ..."