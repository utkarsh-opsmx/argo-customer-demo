#!/bin/sh

( cd opsmx-policy-service ; mvn -e clean install)
[ $? == 1 ] && {
  echo "Building opsmx-policy-service failed"
  exit 1
}

exit 0
